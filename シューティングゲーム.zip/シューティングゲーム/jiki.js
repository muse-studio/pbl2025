//弾クラス
class Tama extends CharaBase
{
	constructor( x,y,vx,vy )
	{
		super( 5,x,y,vx,vy );
		//this.w = 4;
		//this.h = 6;
		this.r=4;
	}
	
	update()
	{
		super.update();
		
		for( let i=0; i<teki.length ;i++)
		{
			if( !teki[i].kill )
			{
				
				if( checkHit(
				
					this.x, this.y, this.r,
					teki[i].x, teki[i].y, teki[i].r
				
				) )
				{
					teki[i].kill=true;
					this.kill=true;
					expl.push(new Expl(20,
						teki[i].x,teki[i].y,
						teki[i].vx>>3,teki[i].vy>>3))
					if (typeof se !== "undefined") se.play("explode", 0.4);//効果音
					if (recordActive)score += 50;

					break;
				}
				
			}
		}
	}
	
	draw()
	{
		super.draw();
	}
}

//自機クラス
class Jiki
{
	constructor()
	{
		this.init();
	}
	// 初期化処理（再起動にも使用）
	init(){
		this.x = (FIELD_W/2)<<8;
		this.y = (FIELD_H-50)<<8;(FIELD_H/2)<<8;
		this.speed  = 512;
		this.anime  = 0;
		this.reload = 0;
		this.relo2  = 0;
		this.r      = 10;
		this.damage = false; // ダメージ中フラグ 
		this.damageTimer = 0; // 残り時間
		this.life = 5; // 残りライフ 
		this.gameOver = false; // ゲームオーバーフラグ
		this.gameClear = false; //クリアフラグ
	}
		
	

	// ダメージを受けたとき呼ばれる
takeDamage()
{ 
	if (this.gameOver||this.gameClear) return;
	this.damage = true;
	this.damageTimer = 20;
	this.life--;
	if (typeof se !== "undefined") se.play("damage", 0.5); // 🎵 被弾音
	if (this.life <= 0) { 
		this.gameOver = true;
		this.damage = false;
	}
}
	//自機の移動
	update()
	{
		// ゲームクリア中
		if (this.gameClear){
			if (key[82]){
				this.init(); // 初期化して再スタート
				score=0;
				tama = [];
				teta = [];
				teki = [];
				expl = [];
				saveResultToFile.saved = false;
				gameStartTime = new Date();
		}
		return;
	}

		// ゲームオーバー時：Rキーでリスタート
		if (this.gameOver){
			if (key[82]) { // Rキー
				this.init(); // 初期化して再スタート
				score=0;
				tama = [];
				teta = [];
				teki = [];
				expl = [];
				saveResultToFile.saved = false;
				gameStartTime = new Date();
			}
			return
		}
		// ダメージ中のタイマー管理
		if (this.damageTimer > 0)
		{ 
			this.damageTimer--;
			if (this.damageTimer <= 0) this.damage = false;
		}
	
		if( key[32] && this.reload==0 )
		{
			se.play("shot",0.2);
			tama.push( new Tama(this.x+(4<<8),this.y-(10<<8),  0,-2000 ) );
			tama.push( new Tama(this.x-(4<<8),this.y-(10<<8),  0,-2000 ) );
			tama.push( new Tama(this.x+(8<<8),this.y-(10<<8), 80,-2000 ) );
			tama.push( new Tama(this.x-(8<<8),this.y-(10<<8),-80,-2000 ) );
			
			this.reload=4;
			if(++this.relo2 ==4)
			{
				this.reload=20;
				this.relo2=0;
			}
		}
		if( !key[32] ) this.reload= this.relo2=0;
		
		if( this.reload>0 ) this.reload--;
		
		if( key[37] && this.x>this.speed )
		{
			this.x-=this.speed;
			if(this.anime>-8 )this.anime--;
		}
		else if( key[39] && this.x<= (FIELD_W<<8)-this.speed )
		{
			this.x+=this.speed;
			if(this.anime<8  )this.anime++;
		}
		else
		{
			if(this.anime>0) this.anime--;
			if(this.anime<0) this.anime++;
		}
		
		if( key[38] && this.y>this.speed )
			this.y-=this.speed;
		if( key[40] && this.y<= (FIELD_H<<8)-this.speed)
			this.y+=this.speed;
	
	
	/// --- クリア条件 ---
// スコアが5000点を超える or 3分生き残ったらクリア
// getRecordedElapsedSec() を使って記録補正済み（pausedAccum を考慮）な経過時間を取得
		const elapsedSec = (typeof getRecordedElapsedSec === "function") ? getRecordedElapsedSec() : ((new Date() - gameStartTime) / 1000);

		if (score >= 5000 || elapsedSec >= 180) {
			this.gameClear = true;
		}

	}
	
	//描画
	draw()
	{
		drawSprite(2 + (this.anime>>2), this.x, this.y );
		
	}
}