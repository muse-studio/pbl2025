# -*- coding: utf-8 -*-
"""
Created on Mon Nov 24 00:15:47 2025

@author: seagull
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile
from scipy import signal

def load_wav(path):
    fs, data = wavfile.read(path)
    if data.ndim > 1:
        data = data.mean(axis=1)  # モノラル化
    return fs, data

def plot_spec(data, fs, title):
    f, t, Sxx = signal.spectrogram(data, fs, nperseg=2048, noverlap=1024)
    plt.pcolormesh(t, f, 10 * np.log10(Sxx), shading='gouraud')
    plt.title(title)
    plt.ylabel("Frequency [Hz]")
    plt.xlabel("Time [sec]")
    plt.colorbar(label="Power [dB]")

# --- 個々の音源 ---
fsA, A = load_wav("vo.wav")
fsB, B = load_wav("int.wav")

# --- 混合音 ---
mix = A[:min(len(A),len(B))] + B[:min(len(A),len(B))]

# --- 分離後の音（例：ツールで得た結果） ---
fsA2, A_sep = load_wav("vo.wav")
fsB2, B_sep = load_wav("int.wav")

plt.figure(figsize=(12, 10))

plt.subplot(3,2,1); plot_spec(A, fsA, "Source A")
plt.subplot(3,2,2); plot_spec(B, fsB, "Source B")
plt.subplot(3,2,3); plot_spec(mix, fsA, "Mixed (A+B)")
plt.subplot(3,2,4); plot_spec(A_sep, fsA2, "Separated A'")
plt.subplot(3,2,5); plot_spec(B_sep, fsB2, "Separated B'")

plt.tight_layout()
plt.show()
