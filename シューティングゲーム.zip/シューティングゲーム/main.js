// main.js
// デバッグのフラグ
const DEBUG = true;

let drawCount = 0;
let fps = 0;
let lastTime = Date.now();

// スムージング
const SMOOTHING = false;

//ゲームスピード(ms)
const GAME_SPEED = 1000 / 60;

//画面サイズ
const SCREEN_W = 320;
const SCREEN_H = 320;

//キャンバスサイズ
const CANVAS_W = SCREEN_W * 2;
const CANVAS_H = SCREEN_H * 2;

//フィールドサイズ
const FIELD_W = SCREEN_W + 120;
const FIELD_H = SCREEN_H + 40;

//星の数
const STAR_MAX = 300;

//キャンバス
let can = document.getElementById("can");
let con = can.getContext("2d");
can.width = CANVAS_W;
can.height = CANVAS_H;
con.mozimageSmoothingEnagbled = SMOOTHING;
con.webkitimageSmoothingEnabled = SMOOTHING;
con.msimageSmoothingEnabled = SMOOTHING;
con.imageSmoothingEnabled = SMOOTHING;

//フィールド（仮想画面）
let vcan = document.createElement("canvas");
let vcon = vcan.getContext("2d");
vcan.width = FIELD_W;
vcan.height = FIELD_H;

//カメラの座標
let camera_x = 0;
let camera_y = 0;

//星の実体
let star = [];

//キーボードの状態
let key = [];

//オブジェクト達
let teki = [];
let teta = [];
let tama = [];
let expl = [];
let score = 0;
let gameStartTime = null; // ★ 開始時刻を記録
let initialStartTime = null; // 補正しない「真の」開始時刻（実時間）
let jiki = new Jiki();

//ファイルを読み込み
let spriteImage = new Image();
spriteImage.src = "sprite.png";

// 効果音マネージャー
const se = new SoundManager();
let soundsReady = false; // サウンド読み込み完了フラグ
// 初期は ON（true）。UI で表示／保存時に使う。
se.setEnabled(true);

// ------- 記録制御フラグ（pauseAccum を使わない方式） -------
let recordActive = true; // true = 記録中, false = 一時停止中
let pauseStart = null; // 一時停止が開始された時刻（ms）
// 非記録（recordActive==false）になってからの実時間を計測するための開始時刻
let nonRecordStart = null; // null または Date.now() のミリ秒

// 非記録（recordActive==false）になってからの実時間で自動 GameOver にする秒数
const NON_RECORD_GAMEOVER_SECONDS = 30;

// キーボードの X キーで強制 GameOver
document.addEventListener("keydown", (e) => {
    if (e.key === "x" || e.key === "X") {
        if (!jiki.gameOver && !jiki.gameClear) {
            console.log("X key pressed -> forcing GAME OVER");
            jiki.gameOver = true;
        }
    }
});
// キーでのミュート切替（M キー）
// M キー（m/M）でトグル
document.addEventListener("keydown", (e) => {
	if (e.key === "m" || e.key === "M") {
		if (typeof se !== "undefined" && se && typeof se.toggleEnabled === "function") {
			const newState = se.toggleEnabled();
			console.log(`Sound ${newState ? "enabled" : "disabled"}`);
		} else {
			// se が未定義ならデバッグログ
			console.warn("Sound manager (se) is not ready to toggle.");
		}
	}
});

// Sキーで停止 / Aキーで再開（resume 時に gameStartTime を直接補正する方式）
document.addEventListener("keydown", (e) => {
	// 記録停止（S）
	if (e.code === "KeyS") {
		if (!recordActive) {
			console.log("🟨 既に記録は停止中です");
			return;
		}
		recordActive = false;
		pauseStart = Date.now();

		// 非記録モード開始のタイミングを記録
		nonRecordStart = Date.now();

		console.log("🟥 記録を停止しました（テストプレイを記録しません）");
		return;
	}

	// 記録再開（A）
	if (e.code === "KeyA") {
		// 再開はゲームが生存中のみ許可（GameOver/GameClear のときは無効）
		if (jiki && (jiki.gameOver || jiki.gameClear)) {
			console.log("🟨 記録を再開できません — ゲームは既に終了状態です。再スタートしてください。");
			return;
		}
		if (recordActive) {
			console.log("🟨 既に記録は有効です");
			return;
		}

		// resume 処理：
		// pauseStart がセットされており、かつその停止が「このゲーム開始後」に行われた場合のみ補正を適用
		if (pauseStart !== null && gameStartTime) {
			if (pauseStart >= gameStartTime.getTime()) {
				const pauseDuration = Date.now() - pauseStart; // ms
				gameStartTime = new Date(gameStartTime.getTime() + pauseDuration);
				pauseStart = null;
				console.log("🟩 記録を再開しました（" + Math.round(pauseDuration / 1000) + " 秒分補正）");
			} else {
				// pauseStart は過去のゲーム由来のため補正せず破棄する
				pauseStart = null;
				console.log("🟩 記録を再開しました（補正は前セッションのため行いません）");
			}
		} else {
			// pauseStart が null のときは単に再開フラグを戻す
			console.log("🟩 記録を再開しました");
		}

		// 非記録モードを終了（nonRecordStart をクリア）
		nonRecordStart = null;

		recordActive = true;
		return;
	}
});

// ゲーム起動は「音の読み込み完了後」にする
(async () => {
	try {
		// 並列でロードを開始（速くなる）
		se.load("shot", "se_shot.mp3"); // 自機の弾
		se.load("enemyShot", "se_enemy.mp3"); // 敵の弾
		se.load("explode", "se_explode.mp3"); // 爆発
		se.load("damage", "se_damage.mp3"); // 被弾
		se.load("spawn", "se_spawn.mp3"); // 敵出現（もしなければ無視可）

		// 全ロード完了（成功/失敗を問わず）を待つ
		const results = await se.waitAllLoaded();
		// 成功したバッファ名をログ出力（デバッグ用）
		const loaded = Object.keys(se.buffers);
		console.log("Sound loading finished. Loaded sounds:", loaded);
		soundsReady = loaded.length > 0; // 1つでも読めていれば true
	} catch (e) {
		console.error("Sound loading encountered an error:", e);
		// errors でもゲームを始められるようにする（ただし効果音は鳴らない）
	}

	// window load のタイミングでゲーム開始（安全に）
	if (document.readyState === "complete") {
		gameInit();
	} else {
		window.addEventListener("load", () => {
			gameInit();
		});
	}
})();

// ゲーム初期化（gameInit）：確実に new Date() で開始時刻をセットする
let gameLoopTimer = null;
function gameInit() {
	for (let i = 0; i < STAR_MAX; i++) star[i] = new Star();

	// 真の開始時刻（補正しない）
	initialStartTime = Date.now();

	// 新しいゲームの開始時刻を必ずリセット（過去の一時停止は引きずらない）
	gameStartTime = new Date();
	pauseStart = null;
	recordActive = true; // 新しいプレイでは記録を有効にする

	// 非記録カウントもリセット
	nonRecordStart = null;

	// 既存ループ開始 — 前のタイマーがあればクリアして重複を防ぐ
	if (gameLoopTimer !== null) clearInterval(gameLoopTimer);
	gameLoopTimer = setInterval(gameLoop, GAME_SPEED);
}

// 記録対象の経過時間（秒）を返すユーティリティ
// 再開時に gameStartTime を補正しているのでここは単純計算で良い
function getRecordedElapsedSec() {
	if (!gameStartTime) return 0;
	const now = Date.now();
	const recordedMs = now - gameStartTime.getTime();
	return Math.max(0, recordedMs / 1000);
}

//オブジェクトをアップデート
function updateObj(obj) {
	for (let i = obj.length - 1; i >= 0; i--) {
		obj[i].update();
		if (obj[i].kill) obj.splice(i, 1);
	}
}

//オブジェクトを描画
function drawObj(obj) {
	for (let i = 0; i < obj.length; i++) obj[i].draw();
}

//移動の処理
function updateAll() {
	updateObj(star);
	updateObj(tama);
	updateObj(teta);
	updateObj(teki);
	updateObj(expl);
	jiki.update();
}

//描画の処理
function drawAll() {
	//描画の処理
	vcon.fillStyle = jiki.damage ? "rgba(255,0,0,0.4)" : "black";
	vcon.fillRect(camera_x, camera_y, SCREEN_W, SCREEN_H);

	drawObj(star);
	drawObj(tama);
	jiki.draw();
	drawObj(teta);
	drawObj(teki);
	drawObj(expl);

	// 自機の範囲 0 ～ FIELD_W
	// カメラの範囲 0 ～ (FIELD_W-SCREEN_W)
	camera_x = (jiki.x >> 8) / FIELD_W * (FIELD_W - SCREEN_W);
	camera_y = (jiki.y >> 8) / FIELD_H * (FIELD_H - SCREEN_H);

	//仮想画面から実際のキャンバスにコピー
	con.drawImage(vcan, camera_x, camera_y, SCREEN_W, SCREEN_H, 0, 0, CANVAS_W, CANVAS_H);
}

// putInfo の修正版：右上に SOUND 表示を追加
function putInfo() {
	//----------------------------------
	// デバッグ表示
	//----------------------------------
	if (DEBUG) {
		drawCount++;
		if (lastTime + 1000 <= Date.now()) {
			fps = drawCount;
			drawCount = 0;
			lastTime = Date.now();
		}
		con.font = "12px 'Impact'";
		con.fillStyle = "white";
		con.fillText("FPS: " + fps, 10, 10);
	}

	//----------------------------------
	// スコア・ライフ・タイム表示（固定UI）
	//----------------------------------
	const elapsedSec = getRecordedElapsedSec();
	const remainingSec = Math.max(0, 180 - elapsedSec);
	const minutes = Math.floor(remainingSec / 60);
	const seconds = Math.floor(remainingSec % 60);

	con.font = "16px sans-serif";
	con.fillStyle = "white";
	con.fillText("SCORE: " + score, 20, 30);
	con.fillText("LIFE: " + jiki.life, 20, 50);
	con.fillText("TIME: " + String(minutes).padStart(2, "0") + ":" + String(seconds).padStart(2, "0"), 20, 70);

	// 追加: 効果音の状態表示（右上）
	const soundStateText = (typeof se !== "undefined" && se && typeof se.enabled !== "undefined") ? (se.enabled ? "ON" : "OFF") : "N/A";
	con.font = "14px sans-serif";
	con.fillStyle = (soundStateText === "ON") ? "#8f8" : (soundStateText === "OFF" ? "#f88" : "#888");
	const textX = CANVAS_W - 140;
	const textY = 30;
	con.fillText("SOUND: " + soundStateText, textX, textY);

	// 記録状態表示（右上のさらに下）
	const recText = recordActive ? "REC: ON" : "REC: OFF";
	con.fillStyle = recordActive ? "#8f8" : "#f88";
	con.fillText(recText, textX, textY + 18);

	//----------------------------------
	// ゲームオーバー表示
	//----------------------------------
	if (jiki.gameOver) {
		// 終了時は一時停止情報をクリア（誤補正防止）
		pauseStart = null;
		nonRecordStart = null;

		con.font = "bold 40px sans-serif";
		con.fillStyle = "red";
		con.fillText("GAME OVER", (CANVAS_W / 2) - 160, (CANVAS_H / 2));
		con.font = "20px sans-serif";
		con.fillStyle = "white";
		con.fillText("Press [R] to Restart", (CANVAS_W / 2) - 120, (CANVAS_H / 2) + 40);
		saveResultToFile("GAME OVER");
	}

	//----------------------------------
	// ゲームクリア表示
	//----------------------------------
	if (jiki.gameClear) {
		// 終了時は一時停止情報をクリア（誤補正防止）
		pauseStart = null;
		nonRecordStart = null;

		con.font = "bold 40px sans-serif";
		con.fillStyle = "yellow";
		con.fillText("GAME CLEAR!", (CANVAS_W / 2) - 150, (CANVAS_H / 2));
		con.font = "20px sans-serif";
		con.fillStyle = "white";
		con.fillText("Press [R] to Restart", (CANVAS_W / 2) - 120, (CANVAS_H / 2) + 40);
		saveResultToFile("GAME CLEAR");
	}
}

//ゲームループ
// --- gameLoop 関数（初期開始実時間 initialStartTime を使い開始2秒間はスポーンを抑制） ---
function gameLoop() {
	updateGamepad(); // パッド

	//----------------------------------------
	// 非記録中の自動GameOver判定（非記録を開始してから一定時間経過したら自動でゲーム終了）
	//----------------------------------------
	if (!recordActive && nonRecordStart) {
		const nonRecordElapsed = (Date.now() - nonRecordStart) / 1000;
		if (nonRecordElapsed >= NON_RECORD_GAMEOVER_SECONDS) {
			// 自動的にゲームオーバーへ
			if (!jiki.gameOver && !jiki.gameClear) {
				console.log("非記録状態が " + NON_RECORD_GAMEOVER_SECONDS + " 秒経過したため自動で GAME OVER にします（非記録中の保護機能）。");
				jiki.gameOver = true;
				// 非記録中なので saveResultToFile は呼ばれても保存はされない（仕様）
			}
		}
	}

	//----------------------------------------
	// 敵の出現頻度調整（残り1分.4000点時1.5倍）
	//----------------------------------------
	// 実際の経過時間（補正しない、本来の開始からの経過）
	let realElapsedSec = 0;
	if (initialStartTime) {
		realElapsedSec = (Date.now() - initialStartTime) / 1000;
	}

	// ゲーム開始から実時間で2秒未満は敵を出現させない
	if (realElapsedSec < 2) {
		// 更新・描画は通常通り行うがスポーン判定はスキップ
		updateAll();
		drawAll();
		con.drawImage(vcan, camera_x, camera_y, SCREEN_W, SCREEN_H, 0, 0, CANVAS_W, CANVAS_H);
		putInfo();
		return;
	}

	// 以降は従来どおり「記録対象の経過時間」を基準にスポーン率等を決める
	const elapsedSec = getRecordedElapsedSec(); // 記録補正済みの経過時間（秒）
	let spawnRate = 27; // 1/x確率で敵出現

	// 残り60秒（＝180 - 120 = 60）になったら出現頻度を1.5倍に
	if (elapsedSec >= 120 || score >= 4000) {
		spawnRate = Math.floor(spawnRate / 1.7);
	}

	// 敵を出す（ゲームオーバー・クリアでないとき）
	if (rand(0, spawnRate) == 1 && !jiki.gameOver && !jiki.gameClear) {
		let type = rand(0, tekiFunc.length - 1);
		teki.push(new Teki(type, rand(0, FIELD_W) << 8, 0, 0, rand(300, 1200)));
		// 敵出現音（ロードされていれば再生）
		if (typeof se !== "undefined") se.play("spawn", 0.2);
	}

	updateAll();
	drawAll();
	con.drawImage(vcan, camera_x, camera_y, SCREEN_W, SCREEN_H, 0, 0, CANVAS_W, CANVAS_H);
	putInfo();
}

// saveResultToFile の修正版（サウンド状態を必ず記録）
// 記録が無効（停止）なら保存しない
function saveResultToFile(resultType) {
	if (!recordActive) {
		console.log("saveResultToFile: 記録は停止中のため保存されません。");
		return;
	}
	if (!(jiki && (jiki.gameOver || jiki.gameClear))) {
		// ここに来るのは通常想定外（ゲームが終了していないのに saveResult を呼んだ場合）
		console.warn("saveResultToFile: ゲーム終了状態でないため保存を中止します。");
		return;
	}
	// すでに保存済みなら二重記録しない
	if (saveResultToFile.saved) return;
	saveResultToFile.saved = true;
	const endTime = new Date();
	const elapsedSec = ((endTime - gameStartTime) / 1000).toFixed(2);
	const timestamp = endTime.toLocaleString();

	// 効果音状態を文字列化（se が未定義なら UNKNOWN）
	let soundState = "UNKNOWN";
	if (typeof se !== "undefined" && se && typeof se.enabled !== "undefined") {
		soundState = se.enabled ? "ON" : "OFF";
	}

	//1回分の記録を作成（日本語表記）
	const record =
		`【${resultType}】\n` +
		`日時: ${timestamp}\n` +
		`経過時間: ${elapsedSec} 秒\n` +
		`スコア: ${score}\n` +
		`サウンド: ${soundState}\n\n`;

	// localStorageに履歴を保持（追記する）
	let history = localStorage.getItem("game_result_history");
	if (!history) history = "";
	history += record;
	localStorage.setItem("game_result_history", history);

	// すべての履歴をテキストファイルとして保存
	const blob = new Blob([history], { type: "text/plain" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = "game_result.txt";
	a.style.display = "none";
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	URL.revokeObjectURL(url);
}

//記録の削除
document.addEventListener("keydown", (e) => {
	if (e.key === "l" || e.key === "L") {
		if (confirm("スコア履歴をリセットしますか？")) {
			localStorage.removeItem("game_result_history");
			alert("スコア履歴を削除しました。");
		}
	}
});

let gamepadConnected = false;

// ゲームパッド接続イベント
window.addEventListener("gamepadconnected", (e) => {
	console.log("Gamepad connected:", e.gamepad.id);
	gamepadConnected = true;
});

// ゲームパッド切断イベント
window.addEventListener("gamepaddisconnected", () => {
	console.log("Gamepad disconnected");
	gamepadConnected = false;
});

// ゲームパッド入力をキー入力に変換
function updateGamepad() {
	if (!gamepadConnected) return;
	const pads = navigator.getGamepads();
	if (!pads) return;

	const pad = pads[0];
	if (!pad) return;

	// 方向キー（または左スティック）をキー配列に反映
	key[37] = pad.axes[0] < -0.5 || pad.buttons[14]?.pressed; // ←
	key[39] = pad.axes[0] > 0.5 || pad.buttons[15]?.pressed; // →
	key[38] = pad.axes[1] < -0.5 || pad.buttons[12]?.pressed; // ↑
	key[40] = pad.axes[1] > 0.5 || pad.buttons[13]?.pressed; // ↓

	// Aボタン or Bボタン → ショット（スペースキー）
	key[32] = pad.buttons[0]?.pressed || pad.buttons[1]?.pressed;

	// Xボタン（多くのコントローラで buttons[2]）で強制 GameOver
	if ((pad.buttons[2] && pad.buttons[2].pressed) && !jiki.gameOver && !jiki.gameClear) {
		console.log("Gamepad X button pressed -> forcing GAME OVER");
		jiki.gameOver = true;
	}

	// STARTボタン（7）でリスタート（Rキー扱い）
	key[82] = pad.buttons[9]?.pressed;
}

window.addEventListener("keydown", () => {
	if (se.ctx.state === "suspended") {
		se.ctx.resume();
		console.log("🔊 AudioContext resumed."); // デバッグ用
	}
}, { once: true });