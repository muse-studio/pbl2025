//敵弾クラス
class Teta extends CharaBase
{
	constructor(sn,x,y,vx,vy)
	{
		super(sn,x,y,vx,vy);
		this.r = 4;
	}
	
	update()
	{
		super.update();
		
		if(!jiki.damage && checkHit(this.x, this.y, this.r,
					jiki.x, jiki.y, jiki.r) )
		{
			this.kill   =true;
			jiki.takeDamage();
		}
		
	}
}


//敵クラス
class Teki extends CharaBase
{
	constructor( tnum,x,y,vx,vy )
	{
		super( tnum,x,y,vx,vy );
		this.flag=false;
		//this.w = 20;
		//this.h = 20;
		this.r=10;
		this.tnum=tnum;
	}
	
	update()
	{
		//共通のアップデート
		super.update();
		//個別のアップデート
		tekiFunc[this.tnum](this);
		
		//当たり判定
		if(!jiki.damage && checkHit(this.x, this.y, this.r,
			jiki.x, jiki.y, jiki.r) )
		{
				this.kill   =true;
				jiki.takeDamage();
		}

	}
	
	
}

function tekiShot(obj,speed){
	let an,dx,dy;
			an=Math.atan2(jiki.y-obj.y,jiki.x-obj.x);
			an+=rand(-10,10)*Math.PI/300;//最悪要らない
			dx = Math.cos( an )* speed;
	        dy = Math.sin( an )* speed;

			teta.push( new Teta( 15,obj.x, obj.y, dx, dy) );
		//効果音
			if (typeof se !== "undefined") se.play("enemyShot", 0.4);
}


//ピンク
function tekiMove01(obj)
{
	if( !obj.flag )
		{
			if( jiki.x > obj.x && obj.vx<120 ) obj.vx+= 4;
			else if( jiki.x < obj.x && obj.vx>-120) obj.vx-= 4;
		}
		else
		{
			if( jiki.x < obj.x && obj.vx<400 ) obj.vx+= 30;
			else if( jiki.x > obj.x && obj.vx>-400) obj.vx-= 30;
		}

		if( Math.abs( jiki.y-obj.y ) < (100<<8)  && !obj.flag)
		{
			obj.flag=true;
			tekiShot(obj,600);
		}

		if( obj.flag && obj.vy>-800) obj.vy-=30;
		//スプライトの変更

		const ptn=[39,40,39,41];
		obj.sn=ptn[(obj.count>>3)&3]
		
}
//鋼
function tekiMove02(obj)
{
	if( !obj.flag )
		{
			if( jiki.x > obj.x && obj.vx<600 ) obj.vx+= 4;
			else if( jiki.x < obj.x && obj.vx>-600) obj.vx-= 4;
		}
		else
		{
			if( jiki.x < obj.x && obj.vx<400 ) obj.vx+= 30;
			else if( jiki.x > obj.x && obj.vx>-400) obj.vx-= 30;
		}

		if( Math.abs( jiki.y-obj.y ) < (100<<8)  && !obj.flag)
		{
			obj.flag=true;
			tekiShot(obj,600)
		}
		//スプライト
		const ptn=[50,51,50,52];
		obj.sn=ptn[(obj.count>>3)&3]

}

let tekiFunc=[
	tekiMove01,
	tekiMove02
]